package com.victxl.projetomongo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProjetomongoApplicationTests {

	@Test
	void contextLoads() {
	}

}
