package com.victxl.projetomongo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProjetomongoApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProjetomongoApplication.class, args);
	}

}
